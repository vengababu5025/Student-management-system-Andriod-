package com.example.nav;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import java.util.jar.Attributes;

public class student_main extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    DatabaseHelper Db;
    TextView name,std_Name;
    String wel="welcome ";
    String Name;

    public DrawerLayout drawerLayout;
    public ActionBarDrawerToggle actionBarDrawerToggle;

    private NavigationView nav;
    private Context context=this;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_main);

        Db=new DatabaseHelper(this);


        drawerLayout = findViewById(R.id.my_drawer_layout);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close);
        nav=(NavigationView)findViewById(R.id.nav_menu);
        nav.setNavigationItemSelectedListener(this);

        // pass the Open and Close toggle for the drawer layout listener
        // to toggle the button
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        // to make the Navigation drawer icon always appear on the action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        name=findViewById(R.id.name);
        std_Name=findViewById(R.id.std_name);
        Intent intent=getIntent();
        Name=intent.getStringExtra("Name");
        String std_name=intent.getStringExtra("std_name");
        name.setText(Name);
        std_Name.setText(wel+std_name);

    }
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        Object menuItem;
        switch (item.getItemId()) {

            case R.id.venga:
                Intent send1 = new Intent(student_main.this, change_pswd.class);
                send1.putExtra("username",Name);
                startActivity(send1);
                break;
            case R.id.update:
                Cursor cursor=Db.getstddata(Name);
                if(cursor.getCount()==0){
                    Toast.makeText(student_main.this,"No entries",Toast.LENGTH_SHORT).show();
                }
                else{
                    while(cursor.moveToNext()){
                        @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME));
                        @SuppressLint("Range") String roll = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_rollno));
                        @SuppressLint("Range") String dept = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_dept));
                        @SuppressLint("Range") String mail = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_mail));
                        @SuppressLint("Range") String year = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_year));
                        @SuppressLint("Range") byte[] image = cursor.getBlob(cursor.getColumnIndex(DatabaseHelper.COLUMN_IMAGE));
                        @SuppressLint("Range") String mname = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_mother_name));
                        @SuppressLint("Range") String fname = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_father_name));
                        @SuppressLint("Range") String address = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_address));
                        @SuppressLint("Range") String phno = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_mobile_no));

                        Intent send2 = new Intent(student_main.this, update_student.class);
                        send2.putExtra("name", name);
                        send2.putExtra("roll", roll);
                        send2.putExtra("dept", dept);
                        send2.putExtra("mail", mail);
                        send2.putExtra("year", year);
                        send2.putExtra("image",image);
                        send2.putExtra("mname",mname);
                        send2.putExtra("fname",fname);
                        send2.putExtra("phno",phno);
                        send2.putExtra("address",address);
                        startActivity(send2);
                    }
                }

                break;
        }
        return false;
    }
}