package com.example.nav;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class update_student extends AppCompatActivity {
    EditText name,roll,dept,year,mail,phno,mname,fname,address;
    ImageView imgstudent;
    DatabaseHelper Db;
    Button update;
    String studentname;
    String getname,getroll,getdept,getmail,getyear,getmname,getfname,getaddress,getmobile;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_student);
        databaseHelper = new DatabaseHelper(this);
        Db=new DatabaseHelper(this);
        name=findViewById(R.id.name);
        roll=findViewById(R.id.roll);
        dept=findViewById(R.id.dept);
        year=findViewById(R.id.year);
        mail=findViewById(R.id.mail);
        phno=findViewById(R.id.phno);
        mname=findViewById(R.id.mname);
        fname=findViewById(R.id.fname);
        address=findViewById(R.id.address);
        imgstudent=findViewById(R.id.imgStudent);
        update=findViewById(R.id.update);

        Intent intent = getIntent();
        String getName = intent.getStringExtra("name");
        String getroll = intent.getStringExtra("roll");
        String getdept = intent.getStringExtra("dept");
        String getmail = intent.getStringExtra("mail");
        String getyear = intent.getStringExtra("year");
        byte[] byteArray = getIntent().getByteArrayExtra("image");
        Bitmap getimage = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        String getfname = intent.getStringExtra("fname");
        String getmname = intent.getStringExtra("mname");
        getaddress=intent.getStringExtra("address");
        getmobile=intent.getStringExtra("phno");

        name.setText(getName);
        roll.setText(getroll);
        dept.setText(getdept);
        year.setText(getyear);
        mail.setText(getmail);
        imgstudent.setImageBitmap(getimage);
        mname.setText(getmname);
        fname.setText(getfname);
        phno.setText(getmobile);
        address.setText(getaddress);

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update_data();
            }
        });
    }

    private void update_data() {

        String mothername = mname.getText().toString().trim();
        String fathername = fname.getText().toString().trim();
        String mobile = phno.getText().toString().trim();
        String addres = address.getText().toString().trim();
        String studentId=mail.getText().toString().trim();

        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("mother_name", mothername);
        values.put("father_name",fathername);
        values.put("mobile_no",mobile);
        values.put("address",addres);

        int rowsAffected = db.update("student", values, "mail = ?",
                new String[]{studentId});

        if (rowsAffected > 0) {
            Toast.makeText(this, "Data updated successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Invalid student ID or current password", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }
}