package com.example.nav;

public class Student1 {
    private int id;
    private String name;
    private byte[] image;
    private String dept;
    private String year;
    private String rollno;

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getRollno() {
        return rollno;
    }

    public void setRollno(String rollno) {
        this.rollno = rollno;
    }

    public Student1() {
    }

    public Student1(int id, String name, byte[] image,String dept,String year,String rollno) {
        this.id = id;
        this.name = name;
        this.image = image;
        this.dept=dept;
        this.year=year;
        this.rollno=rollno;
    }

    // Getters and setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }
}


