package com.example.nav;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class stdlistl extends AppCompatActivity {
    private RecyclerView recyclerView;
    private StudentAdapter adapter;
    private List<Student1> studentList;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stdlistl);

        recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        studentList = new ArrayList<>();
        databaseHelper = new DatabaseHelper(this);
        adapter = new StudentAdapter(this, studentList);
        recyclerView.setAdapter(adapter);
        fetchdata();

    }

    private void fetchdata() {
        studentList.clear();

        // Fetching students from the database
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        String query = "SELECT * FROM " + DatabaseHelper.TABLE_STUDENTS;
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ID));
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME));
                @SuppressLint("Range") byte[] image = cursor.getBlob(cursor.getColumnIndex(DatabaseHelper.COLUMN_IMAGE));
                @SuppressLint("Range") String dept=cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_dept));
                @SuppressLint("Range") String year=cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_year));
                @SuppressLint("Range") String rollno=cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_rollno));

                // Creating a Student object and adding it to the list
                Student1 student = new Student1(id, name, image,dept,year,rollno);
                studentList.add(student);
            } while (cursor.moveToNext());
        }

        cursor.close();
    }
}