package com.example.nav;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class addstudent extends AppCompatActivity {

    EditText name,dept,year,Rollno;
    Button insert,view;
    ImageView img;
    DatabaseHelper db;
    private Bitmap selectedImageBitmap;

    public String imagepath;

    int PICK_IMAGE_REQUEST=1;
    Uri imagefilepath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addstudent);

        name=findViewById(R.id.name);
        dept=findViewById(R.id.dept);
        year=findViewById(R.id.year);
        Rollno=findViewById(R.id.Rollno);
        insert=findViewById(R.id.insert);
        view=findViewById(R.id.show);
        img=findViewById(R.id.img);

        db=new DatabaseHelper(this);

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nametxt=name.getText().toString();
                String depttxt=dept.getText().toString();
                String yeartxt=year.getText().toString();
                String rollnotxt=Rollno.getText().toString();
                Boolean checkinsertdata=db.insertdata(nametxt,selectedImageBitmap,depttxt,yeartxt,rollnotxt);
                if(checkinsertdata==true)
                {
                    name.setText("");
                    dept.setText("");
                    year.setText("");
                    Rollno.setText("");
                    img.setImageResource(R.drawable.mood);
                    Toast.makeText(addstudent.this,"New entry inserted",Toast.LENGTH_LONG).show();
                }

            }
        });
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(addstudent.this,stdlistl.class));
            }
        });

    }
    public void chooseImage(View objectView){
        try {
            Intent objectintent=new Intent();
            objectintent.setType("image/*");
            objectintent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(objectintent,PICK_IMAGE_REQUEST);
        }
        catch(Exception e){
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        try {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null)
            {
                imagefilepath= data.getData();
                selectedImageBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),imagefilepath);
                img.setImageBitmap(selectedImageBitmap);

            }
        }
        catch(Exception e){
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_SHORT).show();
        }

    }

}