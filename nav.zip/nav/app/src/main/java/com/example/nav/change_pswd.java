package com.example.nav;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

public class change_pswd extends AppCompatActivity {



    private EditText editTextNewPassword;
    private Button buttonUpdatePassword;
    private TextView uname;

    String Name;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_pswd);

        editTextNewPassword = findViewById(R.id.pswd);
        buttonUpdatePassword = findViewById(R.id.update);
        uname=findViewById(R.id.username);
        databaseHelper = new DatabaseHelper(this);
        uname=findViewById(R.id.username);
        Intent intent=getIntent();
        Name=intent.getStringExtra("username");
        uname.setText(Name);

        buttonUpdatePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updatePassword();
            }
        });
    }

    private void updatePassword() {

        String newPassword = editTextNewPassword.getText().toString().trim();
        String studentId=Name;

        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("pswd", newPassword);

        int rowsAffected = db.update("student", values, "mail = ?",
                new String[]{studentId});

        if (rowsAffected > 0) {
            Toast.makeText(this, "Password updated successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Invalid student ID or current password", Toast.LENGTH_SHORT).show();
        }

        db.close();
    }
}

