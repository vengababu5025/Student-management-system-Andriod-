package com.example.nav;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class class_incharge_main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_incharge_main);
    }
}