package com.example.nav;

import android.content.Context;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.ViewHolder> {
    private List<Student1> studentList;
    private Context context;

    public StudentAdapter(Context context, List<Student1> studentList) {
        this.context = context;
        this.studentList = studentList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.student_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Student1 student = studentList.get(position);
        holder.txtName.setText(student.getName());

        // Convert byte array to Bitmap and set it to the ImageView
        Bitmap bitmap = BitmapFactory.decodeByteArray(student.getImage(), 0, student.getImage().length);
        holder.imgStudent.setImageBitmap(bitmap);
        holder.txtdept.setText(student.getDept());
        holder.txtyear.setText(student.getYear());
        holder.txtrollno.setText(student.getRollno());
    }

    @Override
    public int getItemCount() {
        return studentList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtName,txtdept,txtyear,txtrollno;
        ImageView imgStudent;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtName = itemView.findViewById(R.id.txtName);
            imgStudent = itemView.findViewById(R.id.imgStudent);
            txtdept = itemView.findViewById(R.id.txtdept);
            txtyear = itemView.findViewById(R.id.txtyear);
            txtrollno = itemView.findViewById(R.id.txtrollno);
        }
    }
}

