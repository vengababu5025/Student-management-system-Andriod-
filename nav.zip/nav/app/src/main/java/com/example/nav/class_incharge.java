package com.example.nav;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class class_incharge extends AppCompatActivity {

    private TextView register;
    private EditText username,password;
    private Button loginButton;

    private SQLiteDatabase db;
    private Cursor cursor;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_incharge);

        SQLiteOpenHelper openHelper = new DatabaseHelper(this);
        db = openHelper.getReadableDatabase();
        register = findViewById(R.id.register);
        username = findViewById(R.id.username);
        password= findViewById(R.id.password);
        loginButton = findViewById(R.id.login);


        loginButton.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("Range")
            @Override
            public void onClick(View v) {
                String uname = username.getText().toString().trim();
                String pswd = password.getText().toString().trim();
                if (uname.isEmpty() || pswd.isEmpty()) {
                    Toast.makeText(class_incharge.this, "Enter your Email and Password to login", Toast.LENGTH_SHORT).show();
                } else {
                    cursor = db.rawQuery("SELECT *FROM " + DatabaseHelper.TABLE_ci + " WHERE " + DatabaseHelper.COL_2 + "=? AND " + DatabaseHelper.COL_3 + "=?", new String[]{uname, pswd});

                    if(cursor.getCount()==0){
                        Toast.makeText(class_incharge.this,"no entries exist",Toast.LENGTH_SHORT).show();
                        return;
                    }

                    while(cursor.moveToNext()){
                        String name=cursor.getString(1);

                        Intent intent=new Intent(class_incharge.this,class_incharge_main.class);


                        startActivity(intent);


                    }

                }
            }
        });


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(class_incharge.this,class_incharge_reg.class));
                finish();
            }
        });



    }



}